#include"grade.h"

char *getNextString(char *source, char delimiter, char *buffer) {
	if(delimiter != ',') delimiter = ',';
	
	while (*source && *source != delimiter) {
		*buffer++ = *source++;
	}

	if (*(buffer - 1) == '\n') *(buffer - 1) = 0;
	else *buffer = 0;

	if (*source == delimiter) source++;

	return source;
}

int readCSV(const char *fileName, Student *student, ui *studentNumber, ui *subjectNumber, char subjectName[][MAX_SUBJECT_NAME]) {
	if(*subjectNumber != 0) *subjectNumber = 0;
	else if(subjectName == NULL) return -2;
	
	Student *p_start = student;
	FILE *p_file = NULL;
	int i = 0;
	
	p_file = fopen(fileName, "rt");
	if (p_file) {
		char oneLineString[128];
		char str[32];
		char* p_pos;
		char delimiter = ',';

		if (fgets(oneLineString, 128, p_file) != NULL) {
			p_pos = getNextString(oneLineString, delimiter, subjectName[0]);
			p_pos = getNextString(p_pos, delimiter, subjectName[0]);
			for (i = 0; i < MAX_SUBJECT; ++i) {
				p_pos = getNextString(p_pos, delimiter, subjectName[i]);
				//printf("%s\n", subjectName[i]);
				if (p_pos[0] == '\0') break;
				++(*subjectNumber);
			}

			while (fgets(oneLineString, 128, p_file) != NULL) {
				p_pos = getNextString(oneLineString, delimiter, student->studentName);
				p_pos = getNextString(p_pos, delimiter, str);
				student->classNumber = atoi(str);

				student->mean = 0;
				for (i = 0; i < *subjectNumber; ++i) {
					p_pos = getNextString(p_pos, delimiter, str);
					student->score[i] = atof(str);
				}
				p_pos = getNextString(p_pos, delimiter, str);
				student->mean = atof(str);
				student++;
			}
			*studentNumber = student - p_start;
		}
		fclose(p_file);
		return 1;
	}
	return -3;
}

int saveCSV(const char *fileName, Node *tail, ui studentNumber, ui subjectNumber, char subjectName[][MAX_SUBJECT_NAME]) {
	if(!tail) return -1;
	else if(studentNumber < 1) return -2;
	else if(subjectNumber < 1) return -3;
	
	FILE *p_file = NULL;
	int i = 0, j = 0;
	Node *temp = tail->next;
	Student student = temp->student;
	
	p_file = fopen(fileName, "wt");
	if (p_file) {
		fprintf(p_file, "Name,Class Number,");
		for (i = 0; i < subjectNumber; ++i) {
			fprintf(p_file, "%s,", subjectName[i]);
		}
		fprintf(p_file, "Average\n");
			
		for (i = 0; i < studentNumber; i++) {
			fprintf(p_file, "%s,%d,", student.studentName, student.classNumber);
			for (j = 0; j < subjectNumber; ++j) {
				fprintf(p_file, "%7.2f,", student.score[j]);
			}
		        fprintf(p_file, "%7.2f\n", student.mean);
			temp = temp->next;
			student = temp->student;
		}
		
		printf("The data was saved in %s.\n", fileName);
		fclose(p_file);
	}
}



int insertAtEnd(Node **ptrTail, Student student, ui subjectNumber) {
	//student error check
	ui i = 0;
	if (student.classNumber < 0) {
		return -1;
	}
	else if (student.mean < 0) {
		return -2;
	}

	for (i = 0; i < subjectNumber; ++i) {
		if (student.score[i] < 0) {
			return -3;
		}
	}

	Node *temp = (Node*)malloc(sizeof(Node));
	if (!temp) return -4;

	Node *tail = *ptrTail;
	if (!tail) {
		temp->student = student;
		temp->next = temp;
		*ptrTail = temp;
	}
	else {
		temp->student = student;
		temp->next = tail->next;
		tail->next = temp;
		*ptrTail = temp;
	}

	return 0;
}

int printList(Node *tail, char subjectName[][MAX_SUBJECT_NAME], ui subjectNumber) {
	if (!tail) return -1;
	else if (subjectNumber > MAX_SUBJECT || subjectNumber == 0) return -2;
	else if (sizeof(subjectName[0]) > MAX_SUBJECT_NAME) return -3;

	int i = 0;
	Node* head = tail->next;
	printf("Name: %s\n", head->student.studentName);
	printf("Class Number: %d\n", head->student.classNumber);
	for (i = 0; i < subjectNumber; ++i)
		printf("%s: %7.2f\n", subjectName[i], head->student.score[i]);
	printf("Average: %7.2f\n\n", head->student.mean);

	Node *currNode = head->next;
	while (currNode != head) {
		printf("Name: %s\n", currNode->student.studentName);
		printf("Class Number: %d\n", currNode->student.classNumber);
		for (i = 0; i < subjectNumber; ++i)
			printf("%s: %7.2f\n", subjectName[i], currNode->student.score[i]);
		printf("Average: %7.2f\n\n", currNode->student.mean);
		currNode = currNode->next;
	}

	return 0;
}

int deleteNode(Node **ptrTail, int classNumber, ui *studentNumber) {
	if (classNumber < 0) return -1;
	else if(*studentNumber < 1) return -2;
	Node *tail = *ptrTail;
	Node *curr = tail;
	Node *prev = NULL;

	if (!tail) return -3;

	prev = curr;
	curr = curr->next;
	while (curr != tail) {
		if (curr->student.classNumber == classNumber) {
			prev->next = curr->next;
			free(curr);
			--(*studentNumber);
			return 1;
		}
		prev = curr;
		curr = curr->next;
	}
	
	if (curr->student.classNumber == classNumber) {
		prev->next = curr->next;
		free(curr);
		*ptrTail = prev;
		--(*studentNumber);
		return 1;
	}

	return 0;
}


int sortList(Node *tail, int select) {
	if (select < 1 || select > 3) return -1;
	if (!tail) return -2;

	Node *head = tail->next;
	Node *currNode1 = tail->next;
	Node *currNode2 = head->next;
	Student temp;
	int cnt = 1;

	switch (select) {
	case 1://name
		while (cnt > 0) {
			cnt = 0;
			currNode1 = tail->next;
			currNode2 = head->next;
			while (currNode2 != head) {
				if (strcmp(currNode1->student.studentName, currNode2->student.studentName) == 1) {
					temp = currNode1->student;
					currNode1->student = currNode2->student;
					currNode2->student = temp;
					++cnt;
				}
				currNode1 = currNode1->next;
				currNode2 = currNode2->next;
			}
		}

		break;

	case 2://average
		while (cnt > 0) {
			cnt = 0;
			currNode1 = tail->next;
			currNode2 = head->next;
			while (currNode2 != head) {
				if (currNode1->student.mean > currNode2->student.mean) {
					temp = currNode1->student;
					currNode1->student = currNode2->student;
					currNode2->student = temp;
					++cnt;
				}
				currNode1 = currNode1->next;
				currNode2 = currNode2->next;
			}
		}

		break;

	case 3://class number
		while (cnt > 0) {
			cnt = 0;
			currNode1 = tail->next;
			currNode2 = head->next;
			while (currNode2 != head) {
				if (currNode1->student.classNumber > currNode2->student.classNumber) {
					temp = currNode1->student;
					currNode1->student = currNode2->student;
					currNode2->student = temp;
					++cnt;
				}
				currNode1 = currNode1->next;
				currNode2 = currNode2->next;
			}
		}
		break;
	}

	return 0;
}
