#include"unitTest.h"
#include"grade.h"

//unit test
//1. void insertAtEnd(Node **ptrTail, Student student);
void unitTestForInsertAtEnd() {
	Node *tail = NULL;
	Student student;
	ui numberOfStudent = 5;
	int result;

	//test case 1
	student.classNumber = -1;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 2
	student.classNumber = 0;
	student.mean = -1;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 3
	student.classNumber = 0;
	student.mean = 0;
	student.score[0] = -1;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 4
	student.score[0] = 0;
	student.score[1] = 101;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 5
	student.score[1] = 100;
	student.score[2] = -0.0001;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 6
	student.score[2] = 1;
	student.score[3] = 100.1;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);

	//test case 7
	student.score[3] = 99.99;
	student.score[4] = 0.0001;
	result = insertAtEnd(&tail, student, numberOfStudent);
	printf("%d\n", result);
}

//2. void printList(Node *tail, char subjectName[][MAX_SUBJECT_NAME], ui subjectCnt);
void unitTestForPrintList() {
	Node *tail = NULL;
	char subjectName[MAX_SUBJECT][MAX_SUBJECT_NAME];
	ui numberOfSubject = 1;
	Student student;
	int result;

	//test node generation
	student.classNumber = 0;
	student.mean = 0;
	student.score[0] = 99.99;
	insertAtEnd(&tail, student, numberOfSubject);

	//test case 1
	numberOfSubject = -1;
	result = printList(tail, subjectName, numberOfSubject);
	printf("%d\n", result);

	//test case 2
	numberOfSubject = 0;
	result = printList(tail, subjectName, numberOfSubject);
	printf("%d\n", result);

	//test case 3
	numberOfSubject = 1;
	Node *temp = tail;
	tail = 0;
	result = printList(tail, subjectName, numberOfSubject);
	printf("%d\n", result);
}

//3. int deleteNode(Node **ptrTail, int classNumber, ui *studentNumber);
void unitTestForDeleteNode() {
	Node *tail = NULL;
	int classNumber;
	int result;
	Student student;
	ui numberOfSubject = 1;
	ui studentNumber = 1;

	//test node generation
	student.classNumber = 0;
	student.mean = 0;
	student.score[0] = 99.99;
	insertAtEnd(&tail, student, numberOfSubject);

	//test case 1
	classNumber = -1;
	result = deleteNode(&tail, classNumber, &studentNumber);
	printf("%d\n", result);

	//test case 2
	classNumber = 1;
	tail = 0;
	result = deleteNode(&tail, classNumber, &studentNumber);
	printf("%d\n", result);
}

//4. void sortList(Node *tail, int select);
void unitTestForSortList() {
	Node *tail = NULL;
	int select;
	int result;
	
	//test node generation
	Student student;
	int subjectNumber = 1;
	student.classNumber = 1;
	student.mean = 0;
	student.score[0] = 99.99;
	insertAtEnd(&tail, student, subjectNumber);

	//test case 1
	select = 0;
	result = sortList(tail, select);
	printf("%d\n", result);

	//test case 2
	select = 4;
	result = sortList(tail, select);
	printf("%d\n", result);

	//test case 3
	select = 1;
	tail = 0;
	result = sortList(tail, select);
	printf("%d\n", result);
}


//5.void saveCSV(const char *fileName, Node *tail, ui studentNumber, ui subjectNumber, char subjectName[][MAX_SUBJECT_NAME]);
void unitTestForSaveCSV() {
    //file read
    char saveFileName[MAX_FILE_NAME];
    memset(saveFileName, '\0', MAX_FILE_NAME);
    printf("Enter the file name:");
    scanf("%s", saveFileName);
    strcat(saveFileName, ".csv");
    
    Node *tail = NULL;
    ui studentNumber = 0;
    ui subjectNumber = 0;
    char subjectName[MAX_SUBJECT][MAX_SUBJECT_NAME];
    int result;

    //test case 1
    tail = NULL;
    result = saveCSV(saveFileName, tail, studentNumber, subjectNumber, subjectName);
    printf("%d\n", result);
    
    //test case 2
    //test node generation
    Student student;
    subjectNumber = 1;
    student.classNumber = 1;
    student.mean = 0;
    student.score[0] = 99.99;
    insertAtEnd(&tail, student, subjectNumber);
	
    studentNumber = 0;
    subjectNumber = 1;
    result = saveCSV(saveFileName, tail, studentNumber, subjectNumber, subjectName);
    printf("%d\n", result);
    
    //test case 3
    studentNumber = 1;
    subjectNumber = 0;
    result = saveCSV(saveFileName, tail, studentNumber, subjectNumber, subjectName);
    printf("%d\n", result);

}


//6. int readCSV(const char *fileName, Student *student, ui *studentNumber, ui *subjectNumber, char subjectName[][MAX_SUBJECT_NAME]);
void unitTestForReadCSV() {
    //file read
    char inputFileName[MAX_FILE_NAME];
    memset(inputFileName, '\0', MAX_FILE_NAME);
    printf("Enter the file name:");
    scanf("%s", inputFileName);
    strcat(inputFileName, ".csv");
    char *temp = inputFileName;
    
    int result;
    Student student;
    ui studentNumber;
    ui subjectNumber;
    char subjectName[MAX_SUBJECT][MAX_SUBJECT_NAME];
    //char *temp2 = subjectName[0];
    
    //test case 1
    subjectNumber = -1;
    result = readCSV(inputFileName, &student, &studentNumber, &subjectNumber, subjectName);
    printf("%d\n", result);
    
    //test case 2
    memset(inputFileName, '\0', MAX_FILE_NAME);
    result = readCSV(inputFileName, &student, &studentNumber, &subjectNumber, subjectName);
    printf("%d\n", result);
}

//7. char *getNextString(char *source, char delimiter, char *buffer);
void unitTestForGetNextString() {
    char source[30] = "test, string";
    char buffer[30];
    char *result;
    
    //test case 1
    char delimiter = '!';
    result = getNextString(source, delimiter, buffer);
    printf("%s\n", source);
    printf("%s\n", result);
}







