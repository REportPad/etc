#pragma once

void unitTestForInsertAtEnd();
void unitTestForPrintList();
void unitTestForDeleteNode();
void unitTestForSortList();
void unitTestForSaveCSV();
void unitTestForReadCSV();
void unitTestForGetNextString();
