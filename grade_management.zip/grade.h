#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME         30//max student name
#define MAX_SUBJECT_NAME 30//max subject name
#define MAX_SUBJECT      30//max subject number
#define MAX_STUDENT      100//max student number
#define MAX_FILE_NAME    30//max file name

typedef unsigned int ui;

typedef struct student {
	char studentName[MAX_NAME];
	int classNumber;
	float score[MAX_SUBJECT];
	float mean;
} Student;


typedef struct node {
	Student student;
	struct node *next;
} Node;


int insertAtEnd(Node **ptrTail, Student student, ui subjectNumber);
int printList(Node *tail, char subjectName[][MAX_SUBJECT_NAME], ui subjectNumber);
int deleteNode(Node **ptrTail, int classNumber, ui *studentNumber);
int sortList(Node *tail, int select);
int saveCSV(const char *fileName, Node *tail, ui studentNumber, ui subjectNumber, char subjectName[][MAX_SUBJECT_NAME]);
char *getNextString(char *source, char delimiter, char *buffer);
int readCSV(const char *fileName, Student *student, ui *studentNumber, ui *subjectNumber, char subjectName[][MAX_SUBJECT_NAME]);



