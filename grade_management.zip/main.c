#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include"grade.h"
#include"unitTest.h"

//#define UNIT_TEST //unit test functions on/off
//#define SERVER //socket communication on/off
#define GRADE_MANAGE //grade management code on/off


void error_handling(char * message);

int main(int argc, char* argv[]){
#ifdef UNIT_TEST
		//unitTestForInsertAtEnd();
		//unitTestForPrintList();
		//unitTestForDeleteNode();
		//unitTestForSortList();
		//unitTestForSaveCSV();		
		//unitTestForReadCSV();
		//unitTestForGetNextString();
		while(1){}
#endif

#ifdef SERVER
    int serv_sock;
    int clnt_sock;
   
    //sockaddr_in은 소켓 주소의 틀을 형셩해주는 구조체로 AF_INET일 경우 사용
    struct sockaddr_in serv_addr;
    struct sockaddr_in clnt_addr; //accept함수에서 사용됨.
    socklen_t clnt_addr_size;
   
    //TCP연결지향형이고 ipv4 도메인을 위한 소켓을 생성
    serv_sock = socket(PF_INET, SOCK_STREAM, 0);

    if(serv_sock == -1)
         error_handling("socket error");
   
    //주소를 초기화한 후 IP주소와 포트 지정
    memset(&serv_addr, 0, sizeof(serv_addr)); 
    serv_addr.sin_family = AF_INET;                //타입: ipv4
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY); //ip주소
    serv_addr.sin_port = htons(atoi(argv[1]));     //port 
    
    //소켓과 서버 주소를 바인딩
    if(bind(serv_sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == -1)
    	error_handling("bind error");
    
    //연결 대기열 5개 생성 
    if(listen(serv_sock, 5)==-1)
    	error_handling("listen error");
    
    //클라이언트로부터 요청이 오면 연결 수락
    clnt_addr_size = sizeof(clnt_addr);
    clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_addr, &clnt_addr_size);
    if(clnt_sock==-1)
        error_handling("accept error");
#endif

#ifdef GRADE_MANAGE
	Student student[MAX_STUDENT];
	Student tempStudent;
	
	ui select = 0;
	ui studentNumber = 0;
	ui subjectNumber = 0;
	char subjectName[MAX_SUBJECT][MAX_SUBJECT_NAME];
	
	Node *tail = NULL;
	Node *head = NULL;
	Node *currNode = NULL;
	int i = 0, j=0, k=0, x=0;
	int classNum;
	int sortSelect;
	char inputFileName[MAX_FILE_NAME];
	char saveFileName[MAX_FILE_NAME];
        char writeString[1024];
	char temp[100];
	
	printf("Enter a filename to read.\n");
	scanf("%[^\n]s", inputFileName);
	strcat(inputFileName, ".csv");

	if (readCSV(inputFileName, student, &studentNumber, &subjectNumber, subjectName)) {
		for (i = 0; i < studentNumber; ++i)
			insertAtEnd(&tail, student[i], subjectNumber);

		while (select != 6) {
			printf("\n\n==========[  MENU  ]==========\n");
#ifdef SERVER
			printf("0. Socket\n");
#endif
			printf("1. Data Output\n");
			printf("2. Data Storage\n");
			printf("3. Data Addition\n");
			printf("4. Data Deletion\n");
			printf("5. Data Sort\n");
			printf("6. Exit\n");
			printf("Selection: ");

			if (scanf("%u", &select)) {
				printf("\n\n");
				switch(select){
				case 0:
				    #ifdef SERVER
				    x=0;
				    memset(writeString, 0, 1024);
				    for(j=0; j < subjectNumber+1; ++j){
				    	for(k=0; k < MAX_SUBJECT_NAME; ++k){
	     			            if(subjectName[j][k] == '\0'){
	     			                writeString[x] = ',';
	     			                ++x;
	     			                break;
	     			            }
              			            writeString[x] = subjectName[j][k];
              			            ++x;
				    	}
				    }
				    
				    head = tail->next;
				    strcat(writeString, head->student.studentName);
	     			    x += strlen(head->student.studentName);
	     			    writeString[x] = ',';
	     			    ++x;
	     			        
	     			    memset(temp, 0, 100);
				    sprintf(temp, "%d", head->student.classNumber);
				    strcat(writeString, temp);
				    x += strlen(temp);
				    writeString[x] = ',';
              			    ++x;
	     			          
	     			    
				    for(k=0; k < subjectNumber; ++k){
				    	memset(temp, 0, 100);
              			        sprintf(temp, "%.2f", head->student.score[k]);
              			        strcat(writeString, temp);
              			        x += strlen(temp);
              			        writeString[x] = ',';
              			        ++x;
				    }
				    
				    memset(temp, 0, 100);
				    sprintf(temp, "%.2f", head->student.mean);
				    strcat(writeString, temp);
				    x += strlen(temp);
				    writeString[x] = ',';
              			    ++x;
				    		
				    currNode = head->next;//currNode->student.studentName
				    while (currNode != head) {
				        strcat(writeString, currNode->student.studentName);
	     			        x += strlen(currNode->student.studentName);
	     			        writeString[x] = ',';
	     			        ++x;
	     			        
	     			        memset(temp, 0, 100);
				        sprintf(temp, "%d", currNode->student.classNumber);
				        strcat(writeString, temp);
				        x += strlen(temp);
				        writeString[x] = ',';
              			        ++x;
	     			          
	     			    
				        for(k=0; k < subjectNumber; ++k){
				    	    memset(temp, 0, 100);
              			            sprintf(temp, "%.2f", currNode->student.score[k]);
              			            strcat(writeString, temp);
              			            x += strlen(temp);
              			            writeString[x] = ',';
              			            ++x;
				        }
				    
				        memset(temp, 0, 100);
				        sprintf(temp, "%.2f", currNode->student.mean);
				        strcat(writeString, temp);
				        x += strlen(temp);
				        writeString[x] = ',';
              			        ++x;
              			    
		                       currNode = currNode->next;
				    }
				    
				    write(clnt_sock, writeString, x);
				    #endif
				break;
				
				case 1:
				    printList(tail, subjectName, subjectNumber);
				    break;
				
				case 2:
				    memset(saveFileName, '\0', MAX_FILE_NAME);
				    printf("Enter the file name:");
				    scanf("%s", saveFileName);
				    strcat(saveFileName, ".csv");
				    saveCSV(saveFileName, tail, studentNumber, subjectNumber, subjectName);
				    break;
				
				case 3:
				    printf("Name:");
				    scanf("%s", tempStudent.studentName);
				    printf("Class Number:");
				    scanf("%d", &tempStudent.classNumber);
				    printf("Score:\n");
				    tempStudent.mean = 0;
				    for (i = 0; i < subjectNumber; ++i) {
				    	printf("%s:", subjectName[i]);
					scanf("%f", &tempStudent.score[i]);
					tempStudent.mean += tempStudent.score[i];
		     		    }
				    tempStudent.mean /= (float)subjectNumber;
				    insertAtEnd(&tail, tempStudent, subjectNumber);
				    ++studentNumber;
				    break;
				
				case 4:
				    printf("Enter the student's class number to delete:");
				    scanf("%d", &classNum);
				    deleteNode(&tail, classNum, &studentNumber);
				    break;
				
				case 5:
				    printf("Select the sort order.\n");
				    printf("[1]Name, [2]Average, [3]Class Number\n");
				    scanf("%d", &sortSelect);
				    sortList(tail, sortSelect);
				    break;
				    
				}				
			}
			else {
				printf("\nYou have entered an invalid. Please re-enter.\n\n");
				rewind(stdin);
			}
		}
	}
	else {
		printf("Unable to open file. Please check the file path.\n");
	}
#endif

#ifdef UNIT_TEST
    //소켓들 닫기
    close(clnt_sock);
    close(serv_sock);
    #endif
	return 0;
}


void error_handling(char *message){
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}
