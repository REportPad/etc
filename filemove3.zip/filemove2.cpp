// filemove2.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <fstream>
#include<io.h>
#include<stdlib.h>
using namespace std;

#define MSIZE 16777216  // 16�ް��� �޸� ���� ����

int fileCopy(const char* src, const char* dst);

//category sorting
int main(){
	string csvPath = "C:\\jobfair\\train_vision6.csv";//csv path
	string imgPath = "C:\\jobfair\\train_img\\";//origination path
	string imgPath2 = imgPath +"*.*";
	string newPath = "C:\\jobfair\\train_img\\c6\\";//destination path "C:\\jobfair\\test_img\\";
	char charNewImgPath[100];
	char charImgPath[100];
	struct _finddata_t fd;
	intptr_t handle;

	string csvName, imgName, fullName[2];
	fstream fs;
	int copyInt = 0;

	fs.open(csvPath, ios::in);

	while (!fs.eof()) {
		if ((handle = _findfirst(imgPath2.c_str(), &fd)) == -1L)
			cout << "No file in directory!" << endl;

		//1. csv file readS
		getline(fs, csvName, '\n');
		//cout << "csv name: " << csvName << endl;
		
		//2. image search
		do {
			imgName = fd.name;
			//cout << "img name: " << imgName << endl;
			if (csvName == imgName) {
				//cout << "search result: " << imgName << endl;

				//3. image move
				fullName[0] = imgPath + imgName;
				//cout << fullName[0] << endl;
				strcpy(charImgPath, fullName[0].c_str());


				fullName[1] = newPath + imgName;
				//cout << fullName[1] << endl;
				strcpy(charNewImgPath, fullName[1].c_str());

				copyInt = fileCopy(charImgPath, charNewImgPath);
				//cout << "copyInt: " << copyInt << endl;
				break;
			}
		} while (_findnext(handle, &fd) == 0);
		_findclose(handle);
	}

	fs.close();
    return 0;
}

int fileCopy(const char* src, const char* dst) {
	//cout << "file copy start" << endl;
	FILE *in, *out;
	char* buf = NULL;
	size_t len;

	if (!strcmpi(src, dst)) return 4; // ������ �纻 ������ �����ϸ� ����

	if ((in = fopen(src, "rb")) == NULL) return 1; // ���� ���� ����
	if ((out = fopen(dst, "wb")) == NULL) { 
		fclose(in); 
		return 2; 
	} // ��� ���� �����

	if ((buf = (char *)malloc(MSIZE)) == NULL) { 
		fclose(in); 
		fclose(out); 
		return 10; 
	} // ���� �޸� �Ҵ�

	while ((len = fread(buf, sizeof(char), sizeof(buf), in)) != NULL)
		if (fwrite(buf, sizeof(char), len, out) == 0) {
			fclose(in); fclose(out);
			free(buf);
			_unlink(dst); // ������ ���� ����� ����
			return 3;
		}

	fclose(in); fclose(out);
	free(buf); // �޸� �Ҵ� ����
	//cout << "filecopy end" << endl;
	return 0;
}